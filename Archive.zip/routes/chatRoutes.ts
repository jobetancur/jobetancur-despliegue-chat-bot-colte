import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { decisionChain } from '../utils/runnables';
import { extractDocumentNumber } from '../utils/helpers';
import { fetchUser } from '../utils/getUser';
import { handleChatRequest } from '../services/chatService';

const router = express.Router();

router.post('/chat', async (req, res) => {
  try {
    const { input, sessionId, userDocumentId, history } = req.body;
    let currentSessionId = sessionId || uuidv4();
    let currentUserDocumentId = userDocumentId;

    if (!currentUserDocumentId) {
      const potentialDocumentId = extractDocumentNumber(input);
      if (potentialDocumentId) {
        const userExists = await fetchUser(potentialDocumentId);
        if (userExists) {
          currentUserDocumentId = potentialDocumentId;
        }
      }
    }

    // Usar handleChatRequest
    const chatResponse = await handleChatRequest(input, currentSessionId, currentUserDocumentId, history || []);

    // Si handleChatRequest no maneja la situación, usar decisionChain como fallback
    if (chatResponse.response === "Lo siento, ha ocurrido un error inesperado. Por favor, intenta nuevamente más tarde.") {
      const decisionChainResponse = await decisionChain.invoke({
        question: input,
        userDocumentId: currentUserDocumentId,
        history: history || []
      });

      console.log("DecisionChain response:", decisionChainResponse);
      res.send({ 
        response: decisionChainResponse, 
        sessionId: currentSessionId, 
        userDocumentId: currentUserDocumentId 
      });
    } else {
      console.log("ChatService response:", chatResponse);
      res.send(chatResponse);
    }

  } catch (error) {
    console.error('Error in chat route:', error);
    if (error instanceof Error) {
      res.status(500).send({ error: error.message || "An unknown error occurred" });
    } else {
      res.status(500).send({ error: "An unknown error occurred" });
    }
  }
});

export default router;