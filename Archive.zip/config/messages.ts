export const MESSAGES = {
    WELCOME: "Bienvenido a Colectora Latam. ¿En qué puedo ayudarte hoy?",
    ASK_DOCUMENT: "Para poder ayudarte, necesito tu número de documento de identidad. ¿Podrías proporcionármelo, por favor?",
    PAYMENT_OPTIONS: "Tenemos varias opciones de pago flexibles, desde 5 hasta 30 días. ¿Qué plazo te vendría mejor?",
    THANK_YOU: "Gracias por tu pago. Esto ayuda a mejorar tu historial crediticio.",
    ERROR: "Lo siento, ha ocurrido un error. Por favor, intenta nuevamente más tarde.",
  };
  
  export type MessageKey = keyof typeof MESSAGES;
  
  export function getMessage(key: MessageKey): string {
    return MESSAGES[key];
  }