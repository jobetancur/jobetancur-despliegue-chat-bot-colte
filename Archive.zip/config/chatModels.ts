import { ChatOpenAI } from "@langchain/openai";
import { OpenAIEmbeddings } from "@langchain/openai";
import dotenv from 'dotenv';

dotenv.config();

export const chatModel = new ChatOpenAI({
  apiKey: process.env.VITE_OPENAI_API_KEY,
  modelName: process.env.VITE_OPENAI_MODEL_NAME,
});

export const embeddingsClient = new OpenAIEmbeddings({
  apiKey: process.env.VITE_OPENAI_API_KEY,
  modelName: process.env.VITE_OPENAI_MODEL_NAME_EMBEDDING || 'text-embedding-ada-002',
});