import { detectIntent, INTENTS, formatCurrency } from '../utils/helpers';
import { fetchUser, fetchDebts } from '../utils/getUser';
import { generatePaymentOptions, calculateTotalDebt } from '../utils/calculate';
import { conversationalRetrievalChain, userInfoQueryChain } from '../utils/runnables';
import { calculateDaysOverdue } from '../utils/calculate';

export async function handleChatRequest(input: string, sessionId: string, userDocumentId: string | null, history: any[]) {
  try {
    const intent = detectIntent(input);
    console.log("Intención detectada:", intent);
    let response;

    if (!userDocumentId && intent !== INTENTS.PROPORCIONAR_DOCUMENTO) {
      return {
        response: "Para poder ayudarte mejor, necesito tu número de documento de identidad. ¿Podrías proporcionármelo, por favor?",
        sessionId,
        userDocumentId
      };
    }

    switch (intent) {
      case INTENTS.PROPORCIONAR_DOCUMENTO:
        console.log("Intensiones", INTENTS.PROPORCIONAR_DOCUMENTO)
        const documentIdMatch = input.match(/\d{6,12}/);
        if (!documentIdMatch) {
          return {
            response: "No pude identificar un número de documento válido. Por favor, proporciona un número de 6 a 12 dígitos.",
            sessionId,
            userDocumentId
          };
        }
        const documentId = documentIdMatch[0];
        const userInfo = await fetchUser(documentId);
        if (userInfo) {
          userDocumentId = documentId;
          const debtInfo = await fetchDebts(userDocumentId);
          if (debtInfo && typeof debtInfo !== 'string') {
            const totalDebt = calculateTotalDebt(debtInfo.amount, debtInfo.interest);
            response = `Gracias, ${userInfo.name}. He encontrado tu información. Tienes una deuda total de ${formatCurrency(totalDebt)}. ¿Quieres conocer las opciones de pago disponibles?`;
          } else {
            response = `Gracias, ${userInfo.name}. He registrado tu número de documento, pero no pude encontrar información sobre deudas. ¿Hay algo más en lo que pueda ayudarte?`;
          }
        } else {
          response = "Lo siento, no pude encontrar información asociada a ese número de documento. ¿Podrías verificarlo?";
        }
        break;

      case INTENTS.CONSULTA_DEUDA:
        console.log("Intensiones", INTENTS.CONSULTA_DEUDA)
        break;
      case INTENTS.INTENCION_PAGO:
        console.log("Intensiones", INTENTS.INTENCION_PAGO)
        break;
      case INTENTS.OPCIONES_PAGO:
        console.log("Intensiones", INTENTS.OPCIONES_PAGO)
        break;
      case INTENTS.ACUERDO:
        console.log("Intensiones", INTENTS.ACUERDO)
        if (userDocumentId) {
          const debtInfo = await fetchDebts(userDocumentId);
          if (debtInfo && typeof debtInfo !== 'string') {
            const daysOverdue = calculateDaysOverdue(debtInfo.dueDate);
            const totalDebt = calculateTotalDebt(debtInfo.amount, debtInfo.interest);
            const interestAmount = totalDebt - debtInfo.amount;
            const options = generatePaymentOptions(debtInfo.amount, interestAmount);
            
            response = `Tu deuda original es de ${formatCurrency(debtInfo.amount)} con intereses acumulados de ${formatCurrency(interestAmount)}. 
                        Tu deuda total actual es de ${formatCurrency(totalDebt)}. 
                        Esta deuda está vencida hace ${daysOverdue} días.

                        Aquí están tus opciones de pago:
                        ${options}

                        ¿Cuál de estas opciones te interesa más? Por favor, indica el número de la opción que prefieras.`;
          } else {
            response = "Lo siento, no pude recuperar la información de tu deuda en este momento. ¿Podrías intentar más tarde?";
          }
        } else {
          response = "Para darte información sobre tu deuda y opciones de pago, necesito tu número de documento. ¿Podrías proporcionármelo?";
        }
        break;

      case INTENTS.RECHAZO:
        console.log("Intensiones", INTENTS.RECHAZO)
        response = "Entiendo que estas opciones pueden no ser ideales para ti en este momento. ¿Hay alguna alternativa que consideres más adecuada para tu situación actual? Estoy aquí para ayudarte a encontrar una solución que funcione para ambos.";
        break;

      default:
        // Usar el modelo de lenguaje para respuestas más generales
        console.log("Intensiones", intent)
        response = await conversationalRetrievalChain.invoke({
          question: input,
          history: history
        });
    }

    return {
      response,
      sessionId,
      userDocumentId
    };
  } catch (error) {
    console.error('Error in chat service:', error);
    return {
      response: "Lo siento, ha ocurrido un error inesperado. Por favor, intenta nuevamente más tarde.",
      sessionId,
      userDocumentId
    };
  }
}