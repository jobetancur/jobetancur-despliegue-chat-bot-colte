import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';
import { SupabaseVectorStore } from "@langchain/community/vectorstores/supabase";
import { OpenAIEmbeddings } from "@langchain/openai";
import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";
import { Document } from "@langchain/core/documents";
import pdfParse from 'pdf-parse/lib/pdf-parse.js';

dotenv.config({ path: '../.env' });

const supabase = createClient(
  process.env.VITE_SUPABASE_URL || "",
  process.env.VITE_SUPABASE_KEY || ""
);

const embeddingsClient = new OpenAIEmbeddings({
  apiKey: process.env.VITE_OPENAI_API_KEY,
  modelName: process.env.VITE_OPENAI_MODEL_NAME_EMBEDDING || 'text-embedding-ada-002',
});

const textSplitter = new RecursiveCharacterTextSplitter({ 
  chunkSize: 1000, 
  chunkOverlap: 200
});

const vectorStore = new SupabaseVectorStore(embeddingsClient, {
  client: supabase,
  tableName: 'documents',
});

async function extractTextFromPDF(filePath: string): Promise<string> {
  try {
    const dataBuffer = fs.readFileSync(filePath);
    const { text } = await pdfParse(dataBuffer);
    return text;
} catch (error) {
    console.error(`Error al extraer texto del PDF ${filePath}:`, error);
    return "";
  }
}

async function processFile(filePath: string): Promise<void> {
    console.log(`Procesando archivo: ${filePath}`);
    
    if (path.extname(filePath).toLowerCase() !== '.pdf') {
        console.log(`Saltando archivo no-PDF: ${filePath}`);
        return;
    }

    const text = await extractTextFromPDF(filePath);
    if (!text) {
        console.log(`No se pudo extraer texto del PDF ${filePath}, saltando...`);
        return;
    }

    console.log(`Texto extraído de ${filePath}, longitud: ${text.length} caracteres`);
    const chunkedDocs = await textSplitter.createDocuments([text], [{ source: filePath }]);

    try {
        await vectorStore.addDocuments(chunkedDocs);
        console.log(`Documento ${filePath} procesado y almacenado exitosamente`);
    } catch (error) {
        console.error(`Error al almacenar el documento ${filePath}:`, error);
        for (const doc of chunkedDocs) {
            try {
                await vectorStore.addDocuments([doc]);
                console.log(`Chunk del documento ${filePath} procesado con éxito`);
            } catch (chunkError) {
                console.error(`Error al procesar un chunk del documento ${filePath}:`, chunkError);
            }
        }
    }
}

async function loadAndStoreDocuments(directory: string): Promise<void> {
  try {
    console.log(`Buscando archivos en`, directory);
    const files = fs.readdirSync(directory);
    console.log(`Archivos encontrados: ${files.join(', ')}`);

    await Promise.all(files.map(file => processFile(path.join(directory, file))));

    console.log('Todos los documentos PDF han sido procesados y almacenados');
  } catch (error) {
    console.error('Error al procesar documentos:', error);
  }
}

const directoryPath = path.resolve('../documents');
loadAndStoreDocuments(directoryPath);