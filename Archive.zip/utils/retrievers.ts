import { createClient } from '@supabase/supabase-js';
import { SupabaseVectorStore } from "@langchain/community/vectorstores/supabase";
import { OpenAIEmbeddings } from "@langchain/openai";

// Conexión a Supabase
const supabaseUrl = 'https://retbuljnvjvusnldofdy.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJldGJ1bGpudmp2dXNubGRvZmR5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcxODA1NjkxNiwiZXhwIjoyMDMzNjMyOTE2fQ.7Y0cmVCiq_C5jPgbr3QHvn5elBXTbeFls29ETR4sux8';
const supabase = createClient(supabaseUrl, supabaseKey);

const embeddingsClient = new OpenAIEmbeddings({apiKey: 'sk-proj-EDReREPbgtCV9QaO23TXT3BlbkFJ0XXS0Yo3GjotugH2CB1d'});

const vectorStore = new SupabaseVectorStore(embeddingsClient,{
    client: supabase,
    tableName: 'documents',
    queryName: 'match_documents'
});

export const retriever = vectorStore.asRetriever();