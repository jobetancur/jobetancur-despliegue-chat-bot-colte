import { ChatMessageHistory } from "langchain/stores/message/in_memory";

export const INTENTS = {
  SALUDO: 'SALUDO',
  PROPORCIONAR_DOCUMENTO: 'PROPORCIONAR_DOCUMENTO',
  CONSULTA_DEUDA: 'CONSULTA_DEUDA',
  INTENCION_PAGO: 'INTENCION_PAGO',
  OPCIONES_PAGO: 'OPCIONES_PAGO',
  QUEJA: 'QUEJA',
  EXCUSA: 'EXCUSA',
  ACUERDO: 'ACUERDO',
  RECHAZO: 'RECHAZO',
  SOLICITAR_HUMANO: 'SOLICITAR_HUMANO',
  GRATITUD: 'GRATITUD',
  DESPEDIDA: 'DESPEDIDA',
  CONFIRMACION: 'CONFIRMACION',
  OTRO: 'OTRO'
};

export const detectIntent = (input: string): string => {
  console.log("Detectando intención para:", input);
  if (/hola|buenos días|buenas tardes|buenas noches/i.test(input)) return INTENTS.SALUDO;
  if (/\d{6,12}/.test(input)) return INTENTS.PROPORCIONAR_DOCUMENTO;
  if (/deuda|debo|cuánto|cuanto|monto/i.test(input)) return INTENTS.CONSULTA_DEUDA;
  if (/pagar|pago|abonar|plan|acuerdo/i.test(input)) return INTENTS.INTENCION_PAGO;
  if (/opciones|alternativas|formas de pago/i.test(input)) return INTENTS.OPCIONES_PAGO;
  if (/no debo|error|equivocados|robo/i.test(input)) return INTENTS.QUEJA;
  if (/enfermo|sin trabajo|problemas|difícil/i.test(input)) return INTENTS.EXCUSA;
  if (/acepto|de acuerdo|está bien/i.test(input)) return INTENTS.ACUERDO;
  if (/no puedo|imposible|no acepto/i.test(input)) return INTENTS.RECHAZO;
  if (/hablar con una persona|agente humano|supervisor/i.test(input)) return INTENTS.SOLICITAR_HUMANO;
  if (/gracias|agradezco|te lo agradezco/i.test(input)) return INTENTS.GRATITUD;
  if (/adiós|hasta luego|chao/i.test(input)) return INTENTS.DESPEDIDA;
  if (/sí|si|claro|por supuesto|okay|ok/i.test(input)) return INTENTS.CONFIRMACION;
  return INTENTS.OTRO;
};

export const extractDocumentNumber = (input: string): string | null => {
  const match = input.match(/\d+/);
  return match ? match[0] : null;
};

export const getMessageHistoryForSession = (messageHistories: any, sessionId: string) => {
  if (messageHistories[sessionId] !== undefined) {
    return messageHistories[sessionId];
  } 
  const newChatSessionHistory = new ChatMessageHistory();
  messageHistories[sessionId] = newChatSessionHistory;
  return newChatSessionHistory;
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP' }).format(amount);
};