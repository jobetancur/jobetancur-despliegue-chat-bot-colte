import { Document } from "@langchain/core/documents";

const convertDocsToString = (documents: Document[]): string => {
    return documents.map((document) => {
      return `<doc>\n${document.pageContent}\n</doc>`
    }).join("\n");
  };

export { convertDocsToString };