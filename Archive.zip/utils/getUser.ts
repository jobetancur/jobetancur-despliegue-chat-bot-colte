import { createClient } from '@supabase/supabase-js';

// Supabase connection
const supabaseUrl = 'https://retbuljnvjvusnldofdy.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJldGJ1bGpudmp2dXNubGRvZmR5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTgwNTY5MTYsImV4cCI6MjAzMzYzMjkxNn0.mMFmvpCn9hl51csog6cZc3C9o56rz1NwzL1v8fg6WFg';
export const supabase = createClient(supabaseUrl, supabaseKey);

export async function addUser(documentId: string, name: string, lastName: string, phone: string, birthDate: Date) {
  const { data, error } = await supabase
    .from('Users')
    .insert([{ document_id: documentId, name: name, lastname: lastName, phone: phone, birth_date: birthDate }]);
  
  if (error) console.log('Error:', error);
  else console.log('User added:', data);
}
  
// Función para obtener un usuario por su document_id
export async function fetchUser(documentId: string) {
  const { data, error } = await supabase
    .from('Users')
    .select('*')
    .eq('document_id', documentId)
    .single();

  if (error) {
    return null; // or handle differently based on your application logic
  }
  return data;
}

// Función para obtener un usuario por su document_id
export async function fetchPhone(phone: string) {
  const { data, error } = await supabase
    .from('Users')
    .select('*') 
    .eq('phone', phone) 
    .single(); 

  if (error) {
    return null; // or handle differently based on your application logic
  }
  return data;
}

export async function fetchDebts(documentId: string): Promise<DebtInfo | string> {
  try {
    const { data, error } = await supabase
      .from('Debts')
      .select('*')
      .eq('document_id', documentId)
      .single();

    if (error) {
      console.error('Error fetching debts:', error);
      return "No se pudo recuperar la información de deudas.";
    }

    if (!data) {
      return "No se encontraron deudas para este documento.";
    }

    console.log('Debt data:', data);

    return {
      amount: data.amount || 0,
      interest: data.interest || 0,
      dueDate: data.due_date ? new Date(data.due_date) : new Date(),
    };
  } catch (error) {
    console.error('Unexpected error in fetchDebts:', error);
    return "Ocurrió un error inesperado al buscar la información de deudas.";
  }
}

interface DebtInfo {
  amount: number;
  interest: number;
  dueDate: Date;
}