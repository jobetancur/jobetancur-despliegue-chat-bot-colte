import { fetchUser, fetchDebts } from './getUser';
import { calculateTotalDebt, generatePaymentPlanDescription } from './calculate';
import { formatCurrency } from '../utils/helpers';

export const validateUserPrompt = async ({ document_id }: { document_id: string }) => {
  console.log("Validando usuario con documento:", document_id);
  const userInfo = await fetchUser(document_id);
  const userDebts = await fetchDebts(document_id);

  if (!userInfo) {
    return { 
      role: "assistant", 
      content: "Lo siento, no pude encontrar información asociada a ese número de documento. ¿Podrías verificar si el número es correcto o proporcionarme algún otro dato para identificarte?" 
    };
  }

  let debtSummary = "";
  let totalDeuda = 0;
  let totalIntereses = 0;

  if (Array.isArray(userDebts) && userDebts.length > 0) {
    totalDeuda = userDebts.reduce((sum, debt) => sum + debt.monto, 0);
    totalIntereses = userDebts.reduce((sum, debt) => sum + debt.intereses, 0);
    
    debtSummary = `Tienes ${userDebts.length} deuda${userDebts.length > 1 ? 's' : ''} pendiente${userDebts.length > 1 ? 's' : ''} por un total de ${formatCurrency(totalDeuda)}. `;
    debtSummary += `Los intereses acumulados son de ${formatCurrency(totalIntereses)}.`;

    // Generar opciones de plan de pago
    const paymentOptions = [5, 15, 30].map(days => generatePaymentPlanDescription(totalDeuda + totalIntereses, days));
    debtSummary += "\n\nOpciones de plan de pago:\n" + paymentOptions.join("\n");
  } else {
    debtSummary = "Actualmente no tienes deudas pendientes con colectora Latam.";
  }

  const userContext = `
    Nombre: ${userInfo.name} ${userInfo.lastname}
    Teléfono: ${userInfo.phone}
    Fecha de nacimiento: ${userInfo.birth_date}
    ${debtSummary}
  `;
  
  return { 
    role: "assistant", 
    content: `${userInfo.name}, gracias por proporcionar tu información. ${debtSummary} ¿En qué puedo ayudarte hoy? ¿Quieres discutir opciones de pago o tienes alguna otra pregunta sobre tu cuenta?` 
  };
};

export const calculatePaymentPlan = (totalDebt: number, days: number) => {
  const interestRate = 0.01; // 1% de interés diario, ajusta según las políticas de Coltefinanciera
  const totalInterest = totalDebt * interestRate * days;
  const totalAmount = totalDebt + totalInterest;
  const dailyPayment = totalAmount / days;

  return {
    totalAmount: totalAmount.toFixed(2),
    dailyPayment: dailyPayment.toFixed(2),
    days: days
  };
};

export const generatePaymentOptions = (totalDebt: number) => {
  const options = [5, 15, 30].map(days => calculatePaymentPlan(totalDebt, days));
  return options;
};