import { RunnableSequence, RunnablePassthrough } from "@langchain/core/runnables";
import { StringOutputParser } from "@langchain/core/output_parsers";
import { retriever } from './retrievers';
import { convertDocsToString } from './docToString';
import { answerGenerationPrompt, rephraseQuestionChainPrompt, queryDetectionPrompt } from './templates';
import { chatModel } from '../config/chatModels';
import { fetchDebts } from '../utils/getUser';
import { HumanMessage, AIMessage, BaseMessage } from '@langchain/core/messages';
import { formatCurrency, detectIntent, INTENTS } from '../utils/helpers';
import { calculateTotalDebt } from '../utils/calculate';


export const documentRetrievalChain = RunnableSequence.from([
  (input: { question: string }) => input.question,
  retriever,
  convertDocsToString
]);

export const retrievalChain = RunnableSequence.from([
  rephraseQuestionChainPrompt,
  chatModel,
  new StringOutputParser(),
]);

export const conversationalRetrievalChain = RunnableSequence.from([
  RunnablePassthrough.assign({
    standalone_question: retrievalChain,
    context: documentRetrievalChain,
    history: (input) => input.history || []
  }),
  answerGenerationPrompt,
  chatModel,
  new StringOutputParser()
]);

export const userInfoQueryChain = RunnableSequence.from([
  {
    queryType: RunnableSequence.from([
      queryDetectionPrompt,
      chatModel,
      new StringOutputParser()
    ]),
    originalQuestion: new RunnablePassthrough()
  },
  (input: { queryType: string; originalQuestion: string }) => {
    const intent = detectIntent(input.originalQuestion);
    if ([INTENTS.CONSULTA_DEUDA, INTENTS.INTENCION_PAGO, INTENTS.OPCIONES_PAGO].includes(intent)) {
      return { result: "USERINFO", queryType: intent };
    } else {
      return { result: "OTHER", queryType: intent };
    }
  }
]);

export const decisionChain = RunnableSequence.from([
  new RunnablePassthrough(),
  async (input: { question: string; userDocumentId: string | null; history?: any[] }) => {
    try {
      const userInfoQuery = await userInfoQueryChain.invoke({ question: input.question });
      
      if (userInfoQuery && userInfoQuery.result === "USERINFO") {
        if (!input.userDocumentId) {
          return { result: "Para poder darte información sobre tu deuda, necesito tu número de documento. ¿Podrías proporcionármelo?" };
        }

        const debtInfo = await fetchDebts(input.userDocumentId);
        console.log('Debt info received:', debtInfo);
        
        if (typeof debtInfo === 'string') {
          return { result: debtInfo }; // Manejo de error si fetchDebts devuelve un string
        }

        if (!debtInfo || !debtInfo.amount || !debtInfo.interest || !debtInfo.dueDate) {
          console.log('Invalid debt info:', debtInfo);
          return { result: "Lo siento, no pude obtener información válida sobre tu deuda. Por favor, intenta más tarde." };
        }

        const totalDebt = calculateTotalDebt(debtInfo.amount, debtInfo.interest);
        const interest = totalDebt - debtInfo.amount;

        return { 
          result: `Tu deuda original es de ${formatCurrency(debtInfo.amount)} con intereses acumulados de ${formatCurrency(interest)}. 
                   Tu deuda total actual es de ${formatCurrency(totalDebt)}. 
                   ¿Te gustaría conocer las opciones de pago disponibles?`
        };
      } else {
        const formattedHistory: BaseMessage[] = input.history ? input.history.map(msg => 
          msg.type === 'human' ? new HumanMessage(msg.data.content) : new AIMessage(msg.data.content)
        ) : [];

        const conversationResponse = await conversationalRetrievalChain.invoke({
          question: input.question,
          history: formattedHistory
        });
        
        return { result: conversationResponse };
      }
    } catch (error) {
      console.error('Error in decisionChain:', error);
      return { result: "Lo siento, ocurrió un error al procesar tu solicitud. Por favor, intenta de nuevo más tarde." };
    }
  },
  (input: { result: string }) => input.result
]);